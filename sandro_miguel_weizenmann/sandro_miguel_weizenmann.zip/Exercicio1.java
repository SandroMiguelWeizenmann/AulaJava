public class Exercicio1 {

	public static void main (String args[]){
		System.out.print("\n\nNumeros pares de 0 � 100: ");
			for(int i=0;i<=100;i++){
				if(i%2==0){
					System.out.print (i + " - ");
					}
			}
	}
}
